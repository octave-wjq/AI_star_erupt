
# coding: utf-8

# In[15]:



# coding: utf-8

# In[ ]:


# coding: utf-8



from sklearn import preprocessing 
from PIL import Image
import numpy as np
import os
import matplotlib.pyplot as plt
from openpyxl import Workbook


dimension=30#标准化矩阵要求的维度


store_folder="E:\\AI\\transform\\result\\"
#矩阵存储文件夹路径    

total_data=np.matrix([np.random.randint(0,1,pow(dimension,2)) for _ in range(1)])
mydir=['newtarget','isstar','asteroid','isnova','known','noise','ghost','pity']
#文件夹的名字，在before_mydir【i】下有所有的mydir
before_mydir=['static_img_20','static_img_20_l','static_img_20_r']

for jj in before_mydir:
    for i in mydir:
        folder='E:\\AI\\transform\\'+jj+'\\'+i
    #目标文件路径
        for filename in os.listdir(folder):
            path_new=path_new=folder+'\\'+filename
            #path_new表示每张图片的地址
            data = ImageToMatrix(path_new)
            data = preprocessing.scale(data)#矩阵数值标准化
            data=mstandardization(data,dimension)#矩阵形状标准化
            #将每张图片的矩阵拉直
#             print(filename)
            data=data.reshape(1,pow(dimension,2))
#             print(i)
            total_data=np.r_[total_data,data]
            #print(data) 
path = store_folder+filename[:-4]+".csv"
#path表示保存在path指向的文件
#print(path)
total_data=np.delete(total_data,0,axis=0)
save(total_data,path)




def ImageToMatrix(filename):
    # 读取图片
    im = Image.open(filename)
    # 显示图片
#     im.show()  
    width,height = im.size
    im = im.convert("L") 
    data = im.getdata()
#    data = np.matrix(data,dtype='float')/255.0
    data = np.matrix(data,dtype='float')
    #new_data = np.reshape(data,(width,height))
    new_data = np.reshape(data,(height,width))
    return new_data
#     new_im = Image.fromarray(new_data)
#     # 显示图片
#     new_im.show()
def MatrixToImage(data):
    data = data*255
    new_im = Image.fromarray(data.astype(np.uint8))
    return new_im
 
 
 


def mstandardization(x,maxhw):
    #x为要标准化的矩阵，maxhw为标准化矩阵的高和宽
    #print(x)
    (h,w)=x.shape
    global temp
    #print("h=",h,"w=",w)
    if(h<maxhw and w<maxhw):
        chazhi_h=maxhw-h
        chazhi_w=maxhw-w
        addm_h=np.matrix([np.random.randint(0,1,w) for _ in range(chazhi_h)])
        #print("addm_h=  ",addm_h)
        #补成与最大矩阵等高的矩阵
        temp=np.r_[x,addm_h]
        addm_w=np.matrix([np.random.randint(0,1,chazhi_w) for _ in range(maxhw)])
        #补成最大矩阵
        temp=np.c_[temp,addm_w]
        return temp
        #print(temp)
    elif(h<maxhw and w==maxhw):
        #print("sucessful enter!")
        chazhi_h=maxhw-h
        addm_h=np.matrix([np.random.randint(0,1,w) for _ in range(chazhi_h)])
        temp=np.r_[x,addm_h]
        return temp
    elif(w<maxhw and h==maxhw):
#         print("sucessful enter!")
        chazhi_w=maxhw-w
        addm_w=np.matrix([np.random.randint(0,1,chazhi_w) for _ in range(maxhw)])
        temp=np.c_[x,addm_w]
        return temp
    else:
        return x;




def save(data,path):
    wb = Workbook()
    ws = wb.active # 激活 worksheet
    [h, l] = data.shape  # h为行数，l为列数
    for i in range(h):
        row = []
        for j in range(l):
            row.append(data[i,j])
        ws.append(row)
    wb.save(path)
    #print("Sucessful")





