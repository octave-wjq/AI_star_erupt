import csv
#生成label


#文件名 可指定路径（绝对）
savefile = 'label_3.csv'


label = [6,732,125,5,181,2813,36,2390]
out = open(savefile,'a',newline='')
data=csv.writer(out,dialect='excel')
for j in range(3):
    i=1
    for count in label:
        for cc in range(count):
            data.writerow(str(i))
        i= i+1
